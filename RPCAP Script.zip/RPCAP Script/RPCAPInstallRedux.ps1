﻿param (
    #[parameter(mandatory=$true)][string]$MgmtIP,
    #[parameter(mandatory=$true)][string]$RpcapIP, 
    #[parameter(mandatory=$true)][string]$SourcePath,
    [switch]$ConfigOnly,
    [int]$RpcapPort = 2003
)

$SourcePath = # path to share accessible to the machine rpcap is being installed on
$MgmtIP = # IP of EDA rpcap reciever
$RpcapIP = (Get-NetIPAddress | Where-Object {$_.AddressState -eq "Preferred" -and $_.ValidLifetime -lt "24:00:00" -and $_.AddressFamily -eq "IPv4"}).IPAddress
$erroractionpreference = "stop"

$pfpath = "${Env:ProgramFiles}\rpcapd"
$confpath = "${pfpath}\rpcapd.ini"
$exepath = "`"${pfpath}\rpcapd.exe`" -v -d -f `"${confpath}`""
$sysname = "npf.sys"
$service_name = "rpcapd"

$config = @"
ActiveClient = $RpcapIP, $RpcapPort`r`n
NullAuthPermit = YES
"@
function CreateTempDir
{
   $tmpDir = [System.IO.Path]::GetTempPath()
   

   [System.IO.Directory]::CreateDirectory($tmpDir) | Out-Null

   $tmpDir
}

function WriteConfig
{
    write-host "Writing config file to $confpath..."
    $config | out-file -filepath $confpath -encoding ascii
}

if ($ConfigOnly) {
    WriteConfig
    exit 
}


#stop the service if its running
$serv = $null
try {
    $serv = get-service -name $service_name
    write-host "Stopping $service_name service..."
    stop-service -inputobject $serv
}
catch { }

#copy files to program files
try {
    $pfdir = get-item -path $pfpath
}
catch {
    $pfdir = new-item -itemtype directory -path $pfpath
}
write-host "Copying files to ${pfpath}..."
$files = Get-ChildItem -Path $SourcePath -File
foreach ($file in $files) {
    copy-item $file.FullName -destination $pfpath
}
  


#copy npf.sys to system32/drivers
$sysdest = "${Env:SystemRoot}\system32\drivers"
write-host "Copying ${sysname} to ${sysdest}..."
copy-item -path "$SourcePath\${sysname}" -destination $sysdest

#write the config file
WriteConfig

#create the service
if ($serv -eq $null) {
    write-host "Creating $service_name service..."
    $serv = new-service -name $service_name -binarypathname $exepath `
                        -displayname "Remote Packet Capture (rpcapd)"
}

try {
    write-host "Starting $service_name service..."
    start-service -inputobject $serv
}
catch {
    write-host "Service Failed to start"
}
